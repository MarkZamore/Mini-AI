#include "support.hpp"
#include <intrin.h>
#include <cwctype>

namespace worker {
static std::wstring relative_path(const std::string & text) {
    if (text.empty() || text.size()>32760 || text.front()=='/' || text.back()=='/' || text.find('\\')!=std::string::npos)
        throw Failure("INCOMPATIBLE_MODEL","Invalid package relative path");
    for (unsigned char c:text) if (c<32 || c==':' || c=='<' || c=='>' || c=='\"' || c=='|' || c=='?' || c=='*')
        throw Failure("INCOMPATIBLE_MODEL","Invalid package path character");
    auto path=wide(text);
    size_t start=0;
    while (start<path.size()) {
        size_t end=path.find(L'/',start);
        if (end==std::wstring::npos) end=path.size();
        std::wstring part=path.substr(start,end-start);
        if (part.empty() || part==L"." || part==L".." || part.back()==L'.' || part.back()==L' ')
            throw Failure("INCOMPATIBLE_MODEL","Invalid package path segment");
        std::wstring stem=part.substr(0,part.find(L'.'));
        std::transform(stem.begin(),stem.end(),stem.begin(),[](wchar_t c){return std::towupper(c);});
        if (stem==L"CON" || stem==L"PRN" || stem==L"AUX" || stem==L"NUL" ||
            (stem.size()==4 && (stem.substr(0,3)==L"COM" || stem.substr(0,3)==L"LPT") &&
             ((stem[3]>=L'1' && stem[3]<=L'9') || stem[3]==L'\u00b9' || stem[3]==L'\u00b2' || stem[3]==L'\u00b3')))
            throw Failure("INCOMPATIBLE_MODEL","Reserved Windows device path");
        start=end+1;
    }
    std::replace(path.begin(),path.end(),L'/',L'\\');
    return path;
}
Handle Package::open(const std::string & relative) const {
    auto path=root+L"\\"+relative_path(relative);
    for (size_t pos=root.size()+1;;) {
        auto next=path.find(L'\\',pos);
        auto prefix=next==std::wstring::npos ? path : path.substr(0,next);
        DWORD attributes=GetFileAttributesW(prefix.c_str());
        if (attributes==INVALID_FILE_ATTRIBUTES || (attributes & FILE_ATTRIBUTE_REPARSE_POINT))
            throw Failure("INCOMPATIBLE_MODEL","Missing file or reparse point in package");
        if (next==std::wstring::npos) { if(attributes & FILE_ATTRIBUTE_DIRECTORY) throw Failure("INCOMPATIBLE_MODEL","Expected ordinary file"); break; }
        pos=next+1;
    }
    Handle handle(CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_FLAG_SEQUENTIAL_SCAN,nullptr));
    if (handle.value==INVALID_HANDLE_VALUE || GetFileType(handle.value)!=FILE_TYPE_DISK)
        throw Failure("INCOMPATIBLE_MODEL","Cannot open ordinary package file read-only");
    if (!contained(root,final_path(handle.value))) throw Failure("INCOMPATIBLE_MODEL","Package file escapes root");
    return handle;
}
static bool hash_text(const std::string & hash) {
    return hash.size()==64 && std::all_of(hash.begin(),hash.end(),[](char c){return (c>='0' && c<='9') || (c>='a' && c<='f');});
}
static void check_inventory_tree(const std::wstring & directory,const std::wstring & executable,size_t & count,size_t depth=0) {
    if (depth>64) throw Failure("INCOMPATIBLE_MODEL","Package directory nesting exceeds limit");
    WIN32_FIND_DATAW item{};
    HANDLE search=FindFirstFileW((directory+L"\\*").c_str(),&item);
    if (search==INVALID_HANDLE_VALUE) throw Failure("INCOMPATIBLE_MODEL","Cannot enumerate package");
    struct Guard { HANDLE h; ~Guard(){FindClose(h);} } guard{search};
    do {
        if (wcscmp(item.cFileName,L".")==0 || wcscmp(item.cFileName,L"..")==0) continue;
        if (++count>16384) throw Failure("INCOMPATIBLE_MODEL","Package file count exceeds limit");
        std::wstring name=item.cFileName;
        std::transform(name.begin(),name.end(),name.begin(),[](wchar_t c){return std::towlower(c);});
        if (item.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) throw Failure("INCOMPATIBLE_MODEL","Reparse points are prohibited in package");
        auto path=directory+L"\\"+item.cFileName;
        if (item.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            if (name==L"native") throw Failure("MODEL_PACKAGE_NOT_SELF_CONTAINED","model/native is prohibited");
            check_inventory_tree(path,executable,count,depth+1);
        } else if ((name.size()>=4 && name.substr(name.size()-4)==L".dll") ||
                   (name.size()>=4 && name.substr(name.size()-4)==L".exe" && !equal_path(path,executable)))
            throw Failure("MODEL_PACKAGE_NOT_SELF_CONTAINED","Package contains a DLL or additional executable");
    } while (FindNextFileW(search,&item));
    if (GetLastError()!=ERROR_NO_MORE_FILES) throw Failure("INCOMPATIBLE_MODEL","Cannot enumerate package");
}
Package::Package(const std::atomic<bool> & stop) {
#ifdef WORKER_TARGET_AVX2
    // Run before any engine call. /arch:AVX2 also enables FMA/F16C and
    // compiler-generated integer instructions; verify the complete profile.
    int cpu[4];
    __cpuid(cpu,0);
    if(cpu[0]<7) throw Failure("INCOMPATIBLE_MODEL","This worker requires the AVX2 CPU profile");
    __cpuid(cpu,1);
    constexpr unsigned ecx_required=(1u<<0)|(1u<<9)|(1u<<12)|(1u<<19)|(1u<<20)|(1u<<23)|(1u<<27)|(1u<<28)|(1u<<29);
    if((unsigned(cpu[2])&ecx_required)!=ecx_required || (_xgetbv(0)&6)!=6)
        throw Failure("INCOMPATIBLE_MODEL","AVX2 profile requires OS AVX state, SSE3/SSSE3/SSE4, POPCNT, FMA and F16C");
    __cpuidex(cpu,7,0);
    constexpr unsigned ebx_required=(1u<<3)|(1u<<5)|(1u<<8);
    if((unsigned(cpu[1])&ebx_required)!=ebx_required)
        throw Failure("INCOMPATIBLE_MODEL","AVX2 profile requires AVX2, BMI1 and BMI2");
    __cpuid(cpu,int(0x80000000u));
    if(unsigned(cpu[0])<0x80000001u) throw Failure("INCOMPATIBLE_MODEL","AVX2 profile requires LZCNT");
    __cpuid(cpu,int(0x80000001u));
    if((unsigned(cpu[2])&(1u<<5))==0) throw Failure("INCOMPATIBLE_MODEL","AVX2 profile requires LZCNT");
#endif
    auto self=executable_path();
    Handle self_handle(CreateFileW(self.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr));
    if (self_handle.value==INVALID_HANDLE_VALUE) throw Failure("INCOMPATIBLE_MODEL","Cannot open worker executable");
    self=final_path(self_handle.value);
    root=self.substr(0,self.find_last_of(L'\\'));
    if (!equal_path(self.substr(self.find_last_of(L'\\')+1),L"inference-worker.exe")) throw Failure("INCOMPATIBLE_MODEL","Unexpected executable name");
    Handle manifest=open("worker.json");
    auto data=parse(read_small(manifest.value,1024*1024));
    keys(data,{"schemaVersion","protocol","executable","engine","revision","architecture","supportedIsa","weights","files","precision","contextTokens","threads","minFreeMemoryBytes","maxProcessMemoryBytes"});
    if (integer(data,"schemaVersion",1,1)!=1 || string(data,"protocol",256)!=protocol ||
        string(data,"executable",256)!="inference-worker.exe" || string(data,"engine",256)!="llama.cpp" ||
        string(data,"architecture",256)!="windows-x64") throw Failure("INCOMPATIBLE_MODEL","Unsupported package contract");
    // Both engine commit and preparation patch identity must be explicit in revision.
    if (string(data,"revision",512)!=WORKER_ENGINE_REVISION)
        throw Failure("INCOMPATIBLE_MODEL","Package engine revision differs from worker");
    if (!data["supportedIsa"].is_array() || data["supportedIsa"].empty() || data["supportedIsa"].size()>32)
        throw Failure("INCOMPATIBLE_MODEL","Invalid supportedIsa");
    std::set<std::string> isa;
    for (auto & item:data["supportedIsa"]) {
#ifdef WORKER_TARGET_AVX2
        if (!item.is_string() || !isa.insert(item.get<std::string>()).second ||
            (item.get<std::string>()!="x86-64" && item.get<std::string>()!="avx2"))
            throw Failure("INCOMPATIBLE_MODEL","This worker requires the explicit x86-64/avx2 package profile");
#else
        if (!item.is_string() || !isa.insert(item.get<std::string>()).second || item.get<std::string>()!="x86-64")
            throw Failure("INCOMPATIBLE_MODEL","This baseline worker requires supportedIsa x86-64 only");
#endif
    }
#ifdef WORKER_TARGET_AVX2
    if(isa!=std::set<std::string>{"x86-64","avx2"})
        throw Failure("INCOMPATIBLE_MODEL","AVX2 worker and manifest profile differ");
#endif
    context=uint32_t(integer(data,"contextTokens",1,1048576));
    threads=uint32_t(integer(data,"threads",1,256));
    precision=string(data,"precision",128);
    minimum_memory=integer(data,"minFreeMemoryBytes",1,9007199254740991ULL);
    maximum_memory=integer(data,"maxProcessMemoryBytes",1,9007199254740991ULL);
    if (maximum_memory>=minimum_memory) throw Failure("INCOMPATIBLE_MODEL","Package has no physical-memory reserve");
    if (available_memory()<minimum_memory) throw Failure("OUT_OF_MEMORY","Not enough free physical memory for this package");
    keys(data["weights"],{"path","sha256"});
    auto weights_relative=string(data["weights"],"path",32760);
    auto weights_hash=string(data["weights"],"sha256",64);
    if (!hash_text(weights_hash)) throw Failure("INCOMPATIBLE_MODEL","Invalid weights hash");
    if (!data["files"].is_array() || data["files"].size()<2 || data["files"].size()>1024)
        throw Failure("INCOMPATIBLE_MODEL","Invalid package inventory");
    std::vector<std::wstring> paths;
    bool found_self=false,found_weights=false;
    size_t tree_count=0;
    check_inventory_tree(root,self,tree_count);
    for (auto & entry:data["files"]) {
        keys(entry,{"path","sha256"});
        auto name=string(entry,"path",32760),hash=string(entry,"sha256",64);
        if (!hash_text(hash)) throw Failure("INCOMPATIBLE_MODEL","Invalid inventory hash");
        auto handle=open(name);
        auto resolved=final_path(handle.value);
        for (const auto & previous:paths) if (equal_path(previous,resolved)) throw Failure("INCOMPATIBLE_MODEL","Duplicate inventory path");
        paths.push_back(resolved);
        if (sha256(handle.value,stop)!=hash) throw Failure("INCOMPATIBLE_MODEL","Package SHA-256 mismatch");
        if (equal_path(resolved,self)) { if(name!="inference-worker.exe") throw Failure("INCOMPATIBLE_MODEL","Noncanonical executable path"); found_self=true; }
        if (name==weights_relative) {
            if (hash!=weights_hash) throw Failure("INCOMPATIBLE_MODEL","Conflicting weights hashes");
            LARGE_INTEGER zero{}; SetFilePointerEx(handle.value,zero,nullptr,FILE_BEGIN);
            std::array<char,4> magic{}; DWORD n=0;
            if (!ReadFile(handle.value,magic.data(),4,&n,nullptr) || n!=4 || std::string(magic.data(),4)!="GGUF")
                throw Failure("INCOMPATIBLE_MODEL","This engine requires actual GGUF model contents");
            weights=resolved; found_weights=true;
        }
        open_files.push_back(std::move(handle));
    }
    if (!found_self || !found_weights) throw Failure("INCOMPATIBLE_MODEL","Executable and weights must be inventoried");
    open_files.push_back(std::move(manifest));
    open_files.push_back(std::move(self_handle));
}
}
