// Preparation-only vocabulary/template counter. Never part of model delivery.
#include "chat.hpp"
#include "llama.h"
#include <iostream>
#include <io.h>
#include <fcntl.h>

static size_t diagnostic_bytes = 0;
static void bounded_log(enum ggml_log_level, const char *text, void *) {
    constexpr size_t limit = 65536;
    size_t length = strnlen_s(text, 8192);
    if (diagnostic_bytes >= limit) return;
    length = std::min(length, limit - diagnostic_bytes);
    diagnostic_bytes += length;
    DWORD written = 0;
    WriteFile(GetStdHandle(STD_ERROR_HANDLE), text, DWORD(length), &written, nullptr);
}

int wmain(int argc, wchar_t **argv) {
    if (argc != 2) return 2;
    try {
        _setmode(_fileno(stdin), _O_BINARY);
        _setmode(_fileno(stdout), _O_BINARY);
        llama_log_set(bounded_log, nullptr);
        auto parameters = llama_model_default_params();
        parameters.vocab_only = true;
        parameters.n_gpu_layers = 0;
        parameters.load_mode = LLAMA_LOAD_MODE_NONE;
        parameters.use_extra_bufts = false;
        parameters.load_mtp = false;
        auto path = worker::utf8(worker::extended(argv[1]));
        std::unique_ptr<llama_model, decltype(&llama_model_free)> model(
            llama_model_load_from_file(path.c_str(), parameters), llama_model_free);
        if (!model) throw std::runtime_error("Cannot load vocabulary metadata");
        const llama_vocab *vocabulary = llama_model_get_vocab(model.get());
        const char *source = llama_model_chat_template(model.get(), nullptr);
        if (!vocabulary || !source || !*source) throw std::runtime_error("Missing vocabulary or chat template");
        worker::ChatTemplate format(source);
        std::string line;
        while (std::getline(std::cin, line)) {
            if (line.size() > worker::max_frame) throw std::runtime_error("Input frame exceeds bound");
            auto request = worker::parse(line);
            worker::keys(request, {"messages"});
            const auto &messages = request.at("messages");
            if (!messages.is_array() || messages.empty() || messages.size() > 4096)
                throw std::runtime_error("Invalid messages array");
            for (const auto &message : messages) {
                worker::keys(message, {"role", "content"});
                auto role = worker::string(message, "role", 16);
                if (role != "user" && role != "system" && role != "assistant")
                    throw std::runtime_error("Invalid role");
                (void)worker::string(message, "content", worker::max_frame, true);
            }
            auto rendered = format.render(messages);
            auto parts = worker::Json::array();
            size_t total = 0;
            for (const auto &part : rendered.parts) {
                // Same segmentation and special-token policy as Worker::render_tokens.
                int n = llama_tokenize(vocabulary, part.val.data(), int(part.val.size()),
                                       nullptr, 0, false, !part.is_input);
                if (n == INT32_MIN || n > 0) throw std::runtime_error("Unexpected token count");
                size_t count = size_t(-int64_t(n));
                if (count) {
                    std::vector<llama_token> tokens(count);
                    int actual = llama_tokenize(vocabulary, part.val.data(), int(part.val.size()),
                                                tokens.data(), int(tokens.size()), false, !part.is_input);
                    if (actual < 0 || size_t(actual) != count) throw std::runtime_error("Tokenization mismatch");
                }
                total += count;
                parts.push_back({{"is_input", part.is_input}, {"tokens", count}});
            }
            std::cout << worker::Json{{"prompt_tokens", total}, {"parts", parts},
                                     {"vocabulary_only", true}, {"generation_context_created", false}}.dump()
                      << '\n' << std::flush;
        }
        return 0;
    } catch (const std::exception &) {
        std::cerr << "Preparation vocabulary/template counting failed\n";
        return 2;
    }
}
