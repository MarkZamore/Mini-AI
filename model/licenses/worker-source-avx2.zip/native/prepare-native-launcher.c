/* Preparation-only stdio launcher for Windows PowerShell 5.1 long-path tests.
 * Never include this executable in model. No installer or elevated API is used. */
#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0A00
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>

int wmain(int argc,wchar_t **argv) {
    if(argc!=3 || wcslen(argv[1])>32700 || wcschr(argv[1],L'"'))return 90;
    wchar_t *end=NULL;unsigned long long limit=_wcstoui64(argv[2],&end,10);
    if(!limit || !end || *end)return 90;
    int status=91;HANDLE job=NULL,handles[3]={NULL,NULL,NULL};
    STARTUPINFOEXW si={0};PROCESS_INFORMATION pi={0};SIZE_T bytes=0;
    wchar_t *command=NULL;LPPROC_THREAD_ATTRIBUTE_LIST attributes=NULL;
    job=CreateJobObjectW(NULL,NULL);if(!job)goto cleanup;
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION info={0};
    info.BasicLimitInformation.LimitFlags=JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE|JOB_OBJECT_LIMIT_PROCESS_MEMORY;
    info.ProcessMemoryLimit=(SIZE_T)limit;
    if(!SetInformationJobObject(job,JobObjectExtendedLimitInformation,&info,sizeof(info)))goto cleanup;
    DWORD sources[3]={STD_INPUT_HANDLE,STD_OUTPUT_HANDLE,STD_ERROR_HANDLE};
    for(int i=0;i<3;i++)if(!DuplicateHandle(GetCurrentProcess(),GetStdHandle(sources[i]),GetCurrentProcess(),&handles[i],0,TRUE,DUPLICATE_SAME_ACCESS))goto cleanup;
    InitializeProcThreadAttributeList(NULL,1,0,&bytes);
    attributes=(LPPROC_THREAD_ATTRIBUTE_LIST)malloc(bytes);if(!attributes)goto cleanup;
    if(!InitializeProcThreadAttributeList(attributes,1,0,&bytes)){free(attributes);attributes=NULL;goto cleanup;}
    if(!UpdateProcThreadAttribute(attributes,0,PROC_THREAD_ATTRIBUTE_HANDLE_LIST,handles,sizeof(handles),NULL,NULL))goto cleanup;
    si.StartupInfo.cb=sizeof(si);si.StartupInfo.dwFlags=STARTF_USESTDHANDLES;
    si.StartupInfo.hStdInput=handles[0];si.StartupInfo.hStdOutput=handles[1];si.StartupInfo.hStdError=handles[2];si.lpAttributeList=attributes;
    SIZE_T chars=wcslen(argv[1])+16;command=(wchar_t *)calloc(chars,sizeof(wchar_t));if(!command)goto cleanup;
    swprintf_s(command,chars,L"\"%s\" --stdio",argv[1]);
    /* Explicit lpApplicationName is essential above MAX_PATH. cwd remains short. */
    if(!CreateProcessW(argv[1],command,NULL,NULL,TRUE,CREATE_NO_WINDOW|CREATE_SUSPENDED|EXTENDED_STARTUPINFO_PRESENT,NULL,NULL,&si.StartupInfo,&pi))goto cleanup;
    if(!AssignProcessToJobObject(job,pi.hProcess)){TerminateProcess(pi.hProcess,92);goto cleanup;}
    char message[128];int length=sprintf_s(message,sizeof(message),"{\"type\":\"preparation_worker_pid\",\"pid\":%lu}\n",pi.dwProcessId);DWORD written=0;
    if(length<=0 || !WriteFile(GetStdHandle(STD_ERROR_HANDLE),message,(DWORD)length,&written,NULL) || written!=(DWORD)length){TerminateProcess(pi.hProcess,92);goto cleanup;}
    if(ResumeThread(pi.hThread)==(DWORD)-1){TerminateProcess(pi.hProcess,92);goto cleanup;}
    for(int i=0;i<3;i++){CloseHandle(handles[i]);handles[i]=NULL;}
    if(WaitForSingleObject(pi.hProcess,INFINITE)==WAIT_OBJECT_0){DWORD code=0;if(GetExitCodeProcess(pi.hProcess,&code))status=(int)code;}
cleanup:
    if(pi.hThread)CloseHandle(pi.hThread);
    if(pi.hProcess)CloseHandle(pi.hProcess);
    if(job)CloseHandle(job);
    for(int i=0;i<3;i++)if(handles[i])CloseHandle(handles[i]);
    if(attributes){DeleteProcThreadAttributeList(attributes);free(attributes);}
    free(command);return status;
}
