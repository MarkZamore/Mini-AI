// Preparation-only diagnostic tool. Never included in a model package.
#include "chat.hpp"
#include <fstream>
#include <iostream>
int wmain(int argc,wchar_t ** argv) {
    if(argc!=2) return 2;
    try {
        std::ifstream input(argv[1],std::ios::binary);
        if(!input) return 2;
        std::string text((std::istreambuf_iterator<char>(input)),{});
        if(text.size()>1024*1024) return 2;
        worker::ChatTemplate format(text);
        std::string line;
        while(std::getline(std::cin,line)) {
            if(line.size()>worker::max_frame) return 2;
            auto request=worker::parse(line);
            auto rendered=format.render(request.at("messages"));
            worker::Json result=worker::Json::array();
            for(const auto & part:rendered.parts) result.push_back({{"is_input",part.is_input},{"text",part.val}});
            std::cout<<worker::Json{{"parts",result}}.dump()<<'\n'<<std::flush;
        }
        return 0;
    } catch(const std::exception & e) {std::cerr<<e.what()<<'\n';return 2;}
}
