; One deliberate instruction from each feature family. Preparation only.
.code
probe_sse2 proc
    pxor xmm0,xmm0
    paddq xmm0,xmm0
    ret
probe_sse2 endp
probe_sse3 proc
    pxor xmm0,xmm0
    haddps xmm0,xmm0
    ret
probe_sse3 endp
probe_ssse3 proc
    pxor xmm0,xmm0
    pshufb xmm0,xmm0
    ret
probe_ssse3 endp
probe_sse41 proc
    pxor xmm0,xmm0
    pmaxsd xmm0,xmm0
    ret
probe_sse41 endp
probe_sse42 proc
    pxor xmm0,xmm0
    pcmpgtq xmm0,xmm0
    ret
probe_sse42 endp
probe_popcnt proc
    xor eax,eax
    popcnt eax,eax
    ret
probe_popcnt endp
probe_avx proc
    vxorps xmm0,xmm0,xmm0
    ret
probe_avx endp
probe_avx2 proc
    vpxor ymm0,ymm0,ymm0
    ret
probe_avx2 endp
probe_fma proc
    pxor xmm0,xmm0
    vfmadd132ps xmm0,xmm0,xmm0
    ret
probe_fma endp
probe_f16c proc
    pxor xmm0,xmm0
    vcvtph2ps xmm0,xmm0
    ret
probe_f16c endp
probe_bmi2 proc
    xor eax,eax
    pdep eax,eax,eax
    ret
probe_bmi2 endp
probe_lzcnt proc
    xor eax,eax
    lzcnt eax,eax
    ret
probe_lzcnt endp
probe_avx512 proc
    vpxord zmm0,zmm0,zmm0
    ret
probe_avx512 endp
end
