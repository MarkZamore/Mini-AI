// Offline preparation tool. It is never included in model or exposed by the stdio worker.
#include "support.hpp"
#include "llama.h"
#include <cstdio>
int wmain(int argc,wchar_t ** argv) {
    if(argc!=4) return 2;
    auto options=llama_model_quantize_default_params();
    if(wcscmp(argv[3],L"Q6_K")==0) options.ftype=LLAMA_FTYPE_MOSTLY_Q6_K;
    else if(wcscmp(argv[3],L"Q5_K_M")==0) options.ftype=LLAMA_FTYPE_MOSTLY_Q5_K_M;
    else return 2;
    options.nthread=8;
    options.allow_requantize=false;
    options.max_buf_size=256*1024*1024;
    try {
        auto source=worker::utf8(worker::extended(argv[1]));
        auto target=worker::utf8(worker::extended(argv[2]));
        return int(llama_model_quantize(source.c_str(),target.c_str(),&options));
    } catch(const std::exception & error) {std::fprintf(stderr,"%s\n",error.what());return 2;}
}
