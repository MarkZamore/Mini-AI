// Preparation-only bounded binary Q6_K encoder. Never included in a model package.
#include <ggml.h>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <io.h>
#include <limits>
#include <vector>

static bool read_exact(void * dst,size_t bytes) {
    auto * p=static_cast<unsigned char *>(dst);
    while(bytes) {auto n=std::fread(p,1,bytes,stdin);if(!n)return false;p+=n;bytes-=n;}
    return true;
}
static bool write_exact(const void * src,size_t bytes) {
    auto * p=static_cast<const unsigned char *>(src);
    while(bytes) {auto n=std::fwrite(p,1,bytes,stdout);if(!n)return false;p+=n;bytes-=n;}
    return std::fflush(stdout)==0;
}
int main(int argc,char ** argv) {
    static_assert(sizeof(float)==4 && std::numeric_limits<float>::is_iec559);
    if(argc!=2 || std::strcmp(argv[1],"--q6-block-stream"))return 2;
    _setmode(_fileno(stdin),_O_BINARY);_setmode(_fileno(stdout),_O_BINARY);
    char magic[8];
    if(!read_exact(magic,8) || std::memcmp(magic,"EAQ6K001",8))return 2;
    if(!write_exact(magic,8))return 2;
    constexpr uint32_t maximum=8192;
    const size_t block_bytes=ggml_type_size(GGML_TYPE_Q6_K);
    if(ggml_blck_size(GGML_TYPE_Q6_K)!=256 || block_bytes!=210)return 2;
    for(;;) {
        uint32_t blocks=0;
        if(!read_exact(&blocks,sizeof(blocks)))return 2;
        if(!blocks)return 0;
        if(blocks>maximum)return 2;
        std::vector<float> input(static_cast<size_t>(blocks)*256);
        std::vector<uint8_t> output(static_cast<size_t>(blocks)*block_bytes);
        if(!read_exact(input.data(),input.size()*sizeof(float)))return 2;
        const size_t actual=ggml_quantize_chunk(GGML_TYPE_Q6_K,input.data(),output.data(),0,blocks,256,nullptr);
        if(actual!=output.size() || !write_exact(output.data(),output.size()))return 2;
    }
}
