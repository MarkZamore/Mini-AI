/* Preparation-only CPUID inventory; never included in a model package. */
#include <windows.h>
#include <intrin.h>
#include <stdio.h>

int main(void) {
    int leaf0[4], leaf1[4] = {0}, leaf7[4] = {0};
    unsigned __int64 xcr0 = 0;
    __cpuid(leaf0, 0);
    if (leaf0[0] >= 1) __cpuidex(leaf1, 1, 0);
    if (leaf0[0] >= 7) __cpuidex(leaf7, 7, 0);
    if (((unsigned)leaf1[2] & (1u << 27)) != 0) xcr0 = _xgetbv(0);
    {
        const unsigned ecx = (unsigned)leaf1[2], edx = (unsigned)leaf1[3];
        const unsigned ebx7 = (unsigned)leaf7[1];
        const int avx_os = ((ecx & (1u << 28)) != 0) && ((xcr0 & 6) == 6);
        const int avx512_os = avx_os && ((xcr0 & 0xe0) == 0xe0);
        printf("{\"scope\":\"preparation_CPU_visibility_only\",\"process_bits\":64,"
               "\"max_basic_leaf\":%u,\"leaf1_ecx\":%u,\"leaf1_edx\":%u,"
               "\"leaf7_ebx\":%u,\"xcr0\":%llu,"
               "\"sse2\":%d,\"sse3\":%d,\"ssse3\":%d,\"sse41\":%d,\"sse42\":%d,"
               "\"popcnt\":%d,\"avx_os\":%d,\"fma_os\":%d,\"f16c_os\":%d,"
               "\"avx2_os\":%d,\"avx512f_os\":%d,\"avx512dq_os\":%d,\"avx512vl_os\":%d,"
               "\"worker_execution_acceptance\":false}\n",
               (unsigned)leaf0[0], ecx, edx, ebx7, xcr0,
               !!(edx & (1u << 26)), !!(ecx & 1), !!(ecx & (1u << 9)),
               !!(ecx & (1u << 19)), !!(ecx & (1u << 20)), !!(ecx & (1u << 23)),
               avx_os, avx_os && !!(ecx & (1u << 12)), avx_os && !!(ecx & (1u << 29)),
               avx_os && !!(ebx7 & (1u << 5)), avx512_os && !!(ebx7 & (1u << 16)),
               avx512_os && !!(ebx7 & (1u << 17)), avx512_os && !!(ebx7 & (1u << 31)));
    }
    return ferror(stdout) ? 1 : 0;
}
