/* Preparation-only positive/negative instruction controls. Never part of model. */
#include <stdio.h>
#include <string.h>

extern void probe_sse2(void);
extern void probe_sse3(void);
extern void probe_ssse3(void);
extern void probe_sse41(void);
extern void probe_sse42(void);
extern void probe_popcnt(void);
extern void probe_avx(void);
extern void probe_avx2(void);
extern void probe_fma(void);
extern void probe_f16c(void);
extern void probe_bmi2(void);
extern void probe_lzcnt(void);
extern void probe_avx512(void);

int main(int argc, char **argv) {
    struct control { const char *name; void (*function)(void); } controls[] = {
        {"sse2",probe_sse2}, {"sse3",probe_sse3}, {"ssse3",probe_ssse3},
        {"sse41",probe_sse41}, {"sse42",probe_sse42}, {"popcnt",probe_popcnt},
        {"avx",probe_avx}, {"avx2",probe_avx2}, {"fma",probe_fma},
        {"f16c",probe_f16c}, {"bmi2",probe_bmi2}, {"lzcnt",probe_lzcnt},
        {"avx512",probe_avx512}
    };
    if(argc!=2)return 2;
    for(unsigned i=0;i<sizeof(controls)/sizeof(controls[0]);++i) {
        if(strcmp(argv[1],controls[i].name)!=0)continue;
        printf("{\"case\":\"%s\",\"stage\":\"before_instruction\"}\n",controls[i].name);
        fflush(stdout);
        controls[i].function();
        printf("{\"case\":\"%s\",\"stage\":\"after_instruction\"}\n",controls[i].name);
        fflush(stdout);
        return 0;
    }
    return 2;
}
